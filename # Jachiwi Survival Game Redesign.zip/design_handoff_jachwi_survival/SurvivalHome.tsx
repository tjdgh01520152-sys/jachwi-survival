"use client";
import { useEffect, useRef, useState } from "react";

/* 자취생 생존기 — 홈 → 로딩(스켈레톤) → 결과, 단일 페이지
   폰트: next/font/google 의 Black_Han_Sans(제목) + Gothic_A1(본문)
   globals.css 에 아래 keyframes 추가 필요 (파일 하단 주석 참고) */

const INK = "#12140F";
const panel = "bg-[#FAF6E8] border-4 border-[#12140F] rounded-[20px] shadow-[6px_6px_0_#12140F]";
const sk = "animate-[shimmer_1.2s_linear_infinite] rounded-lg bg-[length:220%_100%] bg-[linear-gradient(90deg,#E6E2CF_0_30%,#F2EFE0_45%,#E6E2CF_60%)]";

type Meal = {
  slot: string; category: string; name: string; branch: string;
  mainPrice: string; priceNote: string; tag: string; tone: "green" | "blue";
  dist: string; desc: string; pin: { left: string; top: string };
};

const ROUTES: Meal[][] = [
  [
    { slot: "1번째 끼니 · 외식", category: "본죽&비빔밥cafe", name: "7가지야채죽", branch: "본죽&비빔밥cafe 고려대점", mainPrice: "10,000원", priceNote: "매장·배달·프로모션에 따라 달라질 수 있어요", tag: "프랜차이즈 기준가", tone: "green", dist: "48m", desc: "안암역에서 48m, 걸어서 1분이면 도착해요.", pin: { left: "20%", top: "22%" } },
    { slot: "2번째 끼니 · 외식", category: "등촌샤브칼국수", name: "등촌샤브칼국수 (나눠먹기)", branch: "등촌샤브칼국수 안암점", mainPrice: "10,000원", priceNote: "총 20,000원 · 2명 기준", tag: "나눠먹기 · 같이 먹을 사람 필요", tone: "blue", dist: "92m", desc: "나눠먹기 옵션이 켜져 있어 2명 기준으로 계산했어요.", pin: { left: "52%", top: "14%" } },
    { slot: "3번째 끼니 · 외식", category: "돈까스,우동", name: "돈까스,우동", branch: "이세돈가스 고려대점", mainPrice: "13,000원", priceNote: "예상 가격대", tag: "외식", tone: "green", dist: "188m", desc: "조금 걷지만 메뉴가 겹치지 않게 넣었어요.", pin: { left: "63%", top: "52%" } },
    { slot: "4번째 끼니 · 외식", category: "인도음식", name: "인도음식", branch: "오샬", mainPrice: "13,000원", priceNote: "예상 가격대", tag: "외식", tone: "green", dist: "51m", desc: "가장 가까운 가게 중 남은 예산에 맞는 곳이에요.", pin: { left: "44%", top: "76%" } },
  ],
  [
    { slot: "1번째 끼니 · 외식", category: "백반", name: "백반정식", branch: "백소정 안암점", mainPrice: "9,000원", priceNote: "예상 가격대", tag: "외식", tone: "green", dist: "120m", desc: "밥과 국이 같이 나와 한 끼가 든든해요.", pin: { left: "24%", top: "30%" } },
    { slot: "2번째 끼니 · 편의점", category: "편의점", name: "도시락 + 요구르트", branch: "GS25 안암역점", mainPrice: "4,200원", priceNote: "저녁 할인 시간대면 더 저렴해요", tag: "편의점", tone: "blue", dist: "60m", desc: "예산을 아끼려고 한 끼는 편의점으로 뺐어요.", pin: { left: "50%", top: "20%" } },
    { slot: "3번째 끼니 · 요리", category: "직접요리", name: "참치마요 덮밥", branch: "집에서 직접요리", mainPrice: "2,900원", priceNote: "재료비 기준", tag: "직접요리", tone: "green", dist: "0m", desc: "참치캔 묶음을 사면 세 끼까지 나눠 쓸 수 있어요.", pin: { left: "36%", top: "58%" } },
    { slot: "4번째 끼니 · 외식", category: "국수", name: "칼국수 + 공기밥", branch: "용초수 안암점", mainPrice: "8,000원", priceNote: "예상 가격대", tag: "외식", tone: "green", dist: "140m", desc: "국물 있는 끼니를 하나 넣어 구성했어요.", pin: { left: "60%", top: "60%" } },
  ],
];

const PREF_GROUPS = [
  { key: "distance", label: "거리·가격 성향 (하나만 선택)", single: true, opts: ["가까운 곳 우선", "균형", "멀어도 가성비"] },
  { key: "mix", label: "구성", opts: ["요리 섞기", "편의점 OK", "든든하게"] },
  { key: "repeat", label: "반복 허용도 (하나만 선택)", single: true, opts: ["다양하게 먹기", "적당히 반복 가능", "싸면 반복 OK"] },
  { key: "share", label: "나눠먹기", opts: ["나눠먹기 가능"] },
  { key: "style", label: "식사 스타일 (하나만 선택)", single: true, opts: ["최대한 싸게", "적당히 든든하게", "세트/사이드도 OK"] },
  { key: "like", label: "좋아하는 취향", opts: ["매운 음식", "고기", "국물 메뉴", "한식 선호"], more: ["면 요리", "밥 위주", "분식", "양식", "중식", "일식", "샐러드", "디저트"] },
  { key: "avoid", label: "피하고 싶은 것", opts: ["매운 음식 피하기", "면 피하기", "고기 피하기"], more: ["해산물 피하기", "유제품 피하기", "기름진 음식 피하기", "밀가루 피하기", "내장류 피하기"] },
] as const;

const PLANS = [
  { name: "최대 절약 플랜", meta: "18,833원 · 평균 249m" },
  { name: "균형 플랜", meta: "46,500원 · 평균 95m" },
  { name: "가까운 곳 위주 플랜", meta: "45,700원 · 평균 146m" },
];

const LOADING_MSGS = ["근처 가게를 훑는 중…", "예산에 맞는 조합을 고르는 중…", "편의점 행사도 확인하는 중…", "거리랑 가격을 저울질하는 중…"];

function Mascot({ size = 108, pot = true }: { size?: number; pot?: boolean }) {
  return (
    <svg viewBox="0 0 120 140" width={size} height={size * 1.17} fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round">
      <path d="M36 132 L42 84 Q60 74 78 84 L84 132 Z" fill="#7FB8E8" />
      <circle cx="60" cy="48" r="30" fill="#FFE2C4" />
      <path d="M30 46 Q32 12 60 12 Q88 12 90 46 Q76 32 60 34 Q44 36 30 46 Z" fill={INK} />
      <circle cx="50" cy="50" r="3.6" fill={INK} stroke="none" />
      <circle cx="70" cy="50" r="3.6" fill={INK} stroke="none" />
      <path d="M44 40 L53 43" /><path d="M76 40 L67 43" />
      <path d="M51 63 q4.5 5 9 0 q4.5 -5 9 0" strokeWidth={4} />
      <path d="M42 96 L26 112" /><path d="M78 96 L96 108" />
      {pot && <><path d="M82 104 L110 104 L105 128 L87 128 Z" fill="#E5533D" /><path d="M82 110 L108 110" /></>}
    </svg>
  );
}

export default function SurvivalHome() {
  const [place, setPlace] = useState("안암역");
  const [budget, setBudget] = useState(50000);
  const [meals, setMeals] = useState(4);
  const [prefs, setPrefs] = useState<Record<string, string[]>>({});
  const [more, setMore] = useState<Record<string, boolean>>({});
  const [prefOpen, setPrefOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [editing, setEditing] = useState(false);
  const [plan, setPlan] = useState(1);
  const [seed, setSeed] = useState(0);
  const [changed, setChanged] = useState(false);
  const [active, setActive] = useState(-1);
  const [fbOpen, setFbOpen] = useState<Record<number, boolean>>({});
  const [msg, setMsg] = useState(0);
  const timers = useRef<any[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const route = ROUTES[seed % 2];
  const collapsed = (revealed || loading) && !editing;
  const won = (n: number) => n.toLocaleString("ko-KR") + "원";
  const num = (v: string) => parseInt(v.replace(/[^0-9]/g, ""), 10) || 0;
  const perMeal = won(Math.round(budget / Math.max(meals, 1)));

  const toggle = (key: string, label: string, single?: boolean) =>
    setPrefs((p) => {
      const cur = p[key] || [];
      const has = cur.includes(label);
      return { ...p, [key]: single ? (has ? [] : [label]) : has ? cur.filter((x) => x !== label) : [...cur, label] };
    });

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 12, behavior: "smooth" });
  };

  // 실제 구현: setTimeout 대신 추천 API 호출 결과로 교체
  const run = () => {
    setLoading(true); setRevealed(false); setEditing(false); setActive(-1); setMsg(0);
    setTimeout(() => scrollTo("loading"), 60);
    const iv = setInterval(() => setMsg((m) => m + 1), 700);
    const t = setTimeout(() => { clearInterval(iv); setLoading(false); setRevealed(true); setTimeout(() => scrollTo("result"), 60); }, 2000);
    timers.current.push(t as any);
  };

  const markChanged = () => { setChanged(true); const t = setTimeout(() => setChanged(false), 1800); timers.current.push(t as any); };

  const slotInput = "font-black text-[19px] text-[#12140F] bg-[#F5D547] border-0 border-b-[3px] border-[#12140F] rounded-t-lg px-2 py-2.5 text-center outline-none";

  return (
    <div className="min-h-screen bg-[#B7D48F] bg-[radial-gradient(#9BBE72_1.5px,transparent_1.6px)] bg-[length:18px_18px] px-3 pt-3.5 pb-10 text-[#12140F]">
      <div className="mx-auto flex max-w-[460px] flex-col gap-3.5">
        <div className="flex flex-col gap-4">
          <span className="w-fit rounded-full bg-[#12140F] px-3 py-1.5 text-[12px] font-black tracking-[0.14em] text-[#F5D547]">SURVIVAL MODE</span>

          <div className="relative rounded-[22px] border-4 border-[#12140F] bg-[#F5D547] px-[18px] pt-[22px] pb-5 shadow-[8px_8px_0_#12140F]">
            <div className="font-title text-[clamp(46px,15vw,68px)] leading-[0.92] tracking-[-0.02em] [text-shadow:4px_4px_0_#FAF6E8]">자취생<br />생존기</div>
            <div className="mt-3.5 text-[clamp(17px,5vw,21px)] font-black leading-[1.35]">아슬아슬한 식비,<br />끝까지 버틸 수 있을까?</div>
            <div className="absolute -top-3.5 -right-2 rotate-[7deg] rounded-full border-[3px] border-[#12140F] bg-[#E5533D] px-3 py-1.5 text-[13px] font-black text-white">EP.1 개강</div>
          </div>

          <div className={"flex items-end gap-3 p-3.5 " + panel}>
            <div className="shrink-0 animate-[bob_3.4s_ease-in-out_infinite]"><Mascot /></div>
            <div className="relative flex-1 rounded-2xl border-[3px] border-[#12140F] bg-white px-3 py-[11px] text-[14px] font-extrabold leading-[1.45]">
              라면만 먹고 버티긴<br />좀 그렇잖아요?
              <div className="absolute -left-[9px] bottom-3.5 h-3 w-3 rotate-45 border-b-[3px] border-l-[3px] border-[#12140F] bg-white" />
            </div>
          </div>

          <p className="text-[15px] font-semibold leading-[1.6] text-[#1F2417]">위치, 예산, 끼니 수만 입력하면 근처 식당, 편의점, 직접요리를 섞어 현실적인 생존 루트를 짜드려요.</p>

          {collapsed ? (
            <div className={"px-3.5 py-3 " + panel}>
              <div className="flex flex-wrap items-center justify-between gap-2.5">
                <span className="text-[15px] font-black">{place} · {won(budget)} · {meals}끼</span>
                <button onClick={() => setEditing(true)} className="min-h-[44px] rounded-full border-[3px] border-[#12140F] bg-[#F5D547] px-4 text-[13px] font-black">수정</button>
              </div>
            </div>
          ) : (
            <>
              <div className={"flex flex-col gap-3.5 px-[15px] py-4 " + panel}>
                <div className="flex items-center gap-2">
                  <span className="h-[9px] w-[9px] rounded-full bg-[#E5533D]" />
                  <span className="text-[12px] font-black tracking-[0.12em]">MISSION 입력</span>
                </div>
                <div className="text-[19px] font-extrabold leading-[2.3]">
                  나는 <input value={place} onChange={(e) => setPlace(e.target.value)} className={slotInput + " w-[5.6em]"} /> 근처에서{" "}
                  <input value={budget ? budget.toLocaleString("ko-KR") : ""} inputMode="numeric" onChange={(e) => setBudget(Math.min(num(e.target.value), 9999999))} className={slotInput + " w-[4.6em]"} />원 으로{" "}
                  <input value={meals || ""} inputMode="numeric" onChange={(e) => setMeals(Math.min(num(e.target.value), 99))} className={slotInput + " w-[2.4em]"} />끼 를 버텨야 한다
                </div>
                <div className="flex items-center justify-between rounded-xl border-2 border-dashed border-[#9AA18C] bg-[#EDEAD8] px-3 py-2.5">
                  <span className="text-[13px] font-bold text-[#4A5140]">한 끼 평균 가능 금액</span>
                  <span className="text-[17px] font-black">{perMeal}</span>
                </div>
              </div>

              <div className={"flex flex-col gap-3.5 px-[15px] py-4 " + panel}>
                <button onClick={() => setPrefOpen((v) => !v)} className="flex min-h-[44px] w-full items-center justify-between gap-2.5">
                  <span className="text-[15px] font-black">더 정확한 추천을 원한다면 (선택 사항)</span>
                  <span className="text-[13px] font-black text-[#6B7360]">{prefOpen ? "접기 −" : "더 정확하게 +"}</span>
                </button>
                {prefOpen && (
                  <div className="flex flex-col gap-3">
                    {PREF_GROUPS.map((g) => {
                      const picked = prefs[g.key] || [];
                      const opts = more[g.key] && "more" in g ? [...g.opts, ...(g.more as readonly string[])] : g.opts;
                      return (
                        <div key={g.key} className="flex flex-col gap-[7px]">
                          <div className="text-[12px] font-extrabold text-[#6B7360]">{g.label}</div>
                          <div className="flex flex-wrap gap-[7px]">
                            {opts.map((o) => {
                              const on = picked.includes(o);
                              return (
                                <button key={o} aria-pressed={on} onClick={() => toggle(g.key, o, "single" in g && g.single)}
                                  className={"rounded-full border-[3px] px-3.5 py-2 text-[13px] font-extrabold " + (on ? "border-[#12140F] bg-[#E5533D] text-white" : "border-[#C9CDBD] bg-white text-[#12140F]")}>{o}</button>
                              );
                            })}
                            {"more" in g && !more[g.key] && (
                              <button onClick={() => setMore((p) => ({ ...p, [g.key]: true }))} className="rounded-full border-[3px] border-dashed border-[#B4B9A8] px-3.5 py-2 text-[13px] font-extrabold text-[#6B7360]">더 보기 +{(g.more as readonly string[]).length}</button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    <div className="text-[12px] font-bold text-[#6B7360]">선택하지 않아도 기본값으로 추천이 돌아가요.</div>
                  </div>
                )}
              </div>
            </>
          )}

          <button onClick={run} className="font-title w-full rounded-[18px] border-4 border-[#12140F] bg-[#E5533D] px-4 py-5 text-[26px] text-[#FFF8EC] shadow-[7px_7px_0_#12140F] active:translate-x-1 active:translate-y-1 active:shadow-[3px_3px_0_#12140F]">생존 루트 뽑기</button>

          <div className="flex flex-wrap justify-center gap-2">
            {["근처 식당", "편의점 조합", "직접요리"].map((t) => (
              <span key={t} className="rounded-full border-[3px] border-[#12140F] bg-[#FAF6E8] px-3 py-1.5 text-[12px] font-extrabold">{t}</span>
            ))}
          </div>
        </div>

        {loading && (
          <div id="loading" className="mt-1.5 flex flex-col gap-3.5">
            <div className={"flex flex-col gap-3.5 px-4 py-[18px] " + panel}>
              <div className="flex items-end gap-3">
                <div className="relative h-[112px] w-24 shrink-0">
                  {[0, 0.7, 1.3].map((d, i) => (
                    <div key={i} className="absolute top-0 h-4 w-2.5 rounded-md bg-[#C9CDBD]" style={{ left: 18 + i * 22, animation: "steam 2.2s ease-out infinite", animationDelay: d + "s" }} />
                  ))}
                  <div className="absolute bottom-0 left-0 animate-[bob_1.6s_ease-in-out_infinite]"><Mascot size={88} /></div>
                </div>
                <div className="flex flex-1 flex-col gap-[7px]">
                  <span className="font-title text-[22px] leading-[1.2]">생존 루트 계산 중</span>
                  <span className="text-[13px] font-bold leading-[1.5] text-[#4A5140]">{LOADING_MSGS[msg % LOADING_MSGS.length]}</span>
                  <div className="h-3.5 overflow-hidden rounded-full border-[3px] border-[#12140F] bg-[#EDEAD8]">
                    <div className="h-full bg-[#E5533D]" style={{ animation: "bar 1.8s ease-out forwards" }} />
                  </div>
                </div>
              </div>
            </div>
            {/* 결과 레이아웃을 그대로 본뜬 스켈레톤 */}
            <div className={"flex flex-col gap-3 px-[15px] py-4 " + panel}>
              <div className={sk + " h-3 w-16"} />
              <div className="flex flex-wrap items-center gap-2.5"><div className={sk + " h-[42px] w-[210px] rounded-full border-[3px] border-[#12140F]"} /><div className={sk + " h-3 w-28"} /></div>
              <div className="grid grid-cols-2 gap-2">
                {[0, 1].map((i) => <div key={i} className={sk + " h-[74px] rounded-[14px] border-[3px] border-[#12140F]"} />)}
              </div>
              <div className="grid grid-cols-2 gap-x-3.5 gap-y-1.5">
                {[0, 1, 2, 3].map((i) => <div key={i} className={sk + " h-3"} />)}
              </div>
            </div>
            <div className={"flex flex-col gap-[11px] p-[15px] " + panel}>
              <div className="flex items-center justify-between"><div className={sk + " h-4 w-28"} /><div className={sk + " h-3 w-32"} /></div>
              <div className="relative h-[190px] overflow-hidden rounded-[14px] border-[3px] border-[#12140F] bg-[repeating-linear-gradient(135deg,#E3E0CF_0_10px,#DAD7C5_10px_20px)]">
                {[["20%", "22%"], ["52%", "14%"], ["63%", "52%"]].map(([l, t], i) => (
                  <div key={i} className={sk + " absolute h-7 w-14 rounded-full border-[3px] border-[#12140F]"} style={{ left: l, top: t }} />
                ))}
              </div>
            </div>
            {[0, 1].map((i) => (
              <div key={i} className="flex flex-col gap-2.5 rounded-[18px] border-4 border-[#12140F] bg-[#FAF6E8] p-3.5 shadow-[5px_5px_0_#12140F]">
                <div className="flex items-center justify-between"><div className={sk + " h-3 w-28"} /><div className={sk + " h-6 w-24 rounded-full border-2 border-[#12140F]"} /></div>
                <div className={sk + " h-6 w-2/3"} />
                <div className={sk + " h-3 w-1/2"} />
                <div className={sk + " h-3 w-11/12"} />
                <div className={sk + " h-3 w-2/5"} />
              </div>
            ))}
          </div>
        )}

        {revealed && (
          <div id="result" className="mt-1.5 flex flex-col gap-3.5">
            <div className={"flex flex-col gap-3 px-[15px] py-4 " + panel}>
              <div className="text-[12px] font-extrabold text-[#6B7360]">생존 등급</div>
              <div className="flex items-start gap-3">
                <svg viewBox="0 0 90 90" width="66" height="66" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <circle cx="45" cy="45" r="30" fill="#FFE2C4" />
                  <path d="M15 43 Q17 11 45 11 Q73 11 75 43 Q60 29 45 31 Q30 33 15 43 Z" fill={INK} />
                  <circle cx="35" cy="48" r="3.6" fill={INK} stroke="none" /><circle cx="55" cy="48" r="3.6" fill={INK} stroke="none" />
                  <path d="M28 40 L37 43" /><path d="M62 40 L53 43" />
                  <path d="M36 62 q4.5 5 9 0 q4.5 -5 9 0" strokeWidth={4} />
                </svg>
                <div className="flex flex-1 flex-col gap-1.5">
                  <span className="font-title self-start rounded-full border-[3px] border-[#12140F] bg-[#B7D48F] px-4 py-2 text-[20px]">동네 맛집 탐험 계급</span>
                  <span className="text-[13px] font-extrabold text-[#3C4633]">이제 한 끼다운 선택지가 보이기 시작해요.</span>
                  <span className="text-[12px] font-bold text-[#6B7360]">칭호 · 동네 맛집 탐험가</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="flex flex-col gap-1 rounded-[14px] border-[3px] border-[#12140F] bg-[#F5D547] px-3.5 py-3">
                  <span className="text-[12px] font-extrabold text-[#4A5140]">예산 사용률</span>
                  <span className="font-title text-[30px] leading-none">93%</span>
                </div>
                <div className="flex flex-col gap-1 rounded-[14px] border-[3px] border-[#12140F] bg-[#12140F] px-3.5 py-3 text-[#FAF6E8]">
                  <span className="text-[12px] font-extrabold text-[#B7D48F]">남은 돈</span>
                  <span className="font-title text-[30px] leading-none">3,500원</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-x-3.5 gap-y-1.5">
                {[["총 예산", "50,000원"], ["예상 지출", "46,500원"], ["한 끼 평균", "11,625원"], ["평균 거리", "95m"]].map(([l, v]) => (
                  <div key={l} className="flex items-baseline justify-between gap-2"><span className="text-[12px] font-bold text-[#6B7360]">{l}</span><span className="text-[13px] font-extrabold">{v}</span></div>
                ))}
              </div>
              <div className="flex flex-wrap gap-[7px]">
                {["메뉴 다양성 100점", "외식 4끼", "편의점 0끼", "요리 0끼"].map((c) => (
                  <span key={c} className="rounded-full border-2 border-[#12140F] bg-[#EDEAD8] px-2.5 py-1 text-[12px] font-extrabold">{c}</span>
                ))}
              </div>
              <div className="text-[12px] font-bold text-[#6B7360]">추천 성향 · 가격 민감도 높음 · 가까운 곳 선호</div>
            </div>

            <div className={"flex flex-col gap-[11px] p-[15px] " + panel}>
              <div className="flex flex-wrap items-center justify-between gap-1.5">
                <span className="text-[15px] font-black">안암 생존 지도</span>
                <div className="flex gap-2.5 text-[11px] font-extrabold">
                  {[["내 위치", "#12140F"], ["식당", "#E5533D"], ["편의점", "#1B7F3B"]].map(([l, c]) => (
                    <span key={l} className="flex items-center gap-1"><span className="h-[9px] w-[9px] rounded-full" style={{ background: c }} />{l}</span>
                  ))}
                </div>
              </div>
              {/* 카카오맵 SDK 를 이 컨테이너에 마운트. 핀은 카드 선택과 연동 */}
              <div id="kakao-map" className="relative h-[190px] overflow-hidden rounded-[14px] border-[3px] border-[#12140F] bg-[repeating-linear-gradient(135deg,#DDE7CB_0_10px,#D2DFBC_10px_20px)]">
                <div className="absolute left-[34%] top-[56%] rounded-full border-[3px] border-[#12140F] bg-[#12140F] px-2.5 py-[5px] text-[12px] font-black text-[#FFF8EC]">내 위치</div>
                {route.map((m, i) => (
                  <div key={i} className="absolute rounded-full border-[3px] border-[#12140F] px-2.5 py-[5px] text-[12px] font-black text-[#FFF8EC] transition-transform"
                    style={{ left: m.pin.left, top: m.pin.top, background: active === i ? INK : "#E5533D", transform: active === i ? "scale(1.25)" : "scale(1)" }}>{i + 1}끼</div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {PLANS.map((p, i) => (
                <button key={p.name} onClick={() => { setPlan(i); setSeed(i === 0 ? 1 : 0); setActive(-1); markChanged(); }}
                  className={"flex flex-1 basis-[130px] flex-col items-start gap-[3px] rounded-[14px] border-[3px] px-3.5 py-3 text-left " + (plan === i ? "border-[#E5533D] bg-[#FFE9E4]" : "border-[#12140F] bg-[#FAF6E8]")}>
                  <span className="text-[14px] font-black">{p.name}</span>
                  <span className="text-[12px] font-bold text-[#4A5140]">{p.meta}</span>
                </button>
              ))}
              <button onClick={() => { setSeed((s) => s + 1); setActive(-1); markChanged(); }} className="rounded-[14px] border-[3px] border-[#12140F] bg-[#F5D547] px-3.5 py-3 text-[13px] font-black">전체 다시 추천</button>
            </div>

            {route.map((m, i) => (
              <div key={i} onClick={() => setActive(i)}
                className="flex cursor-pointer flex-col gap-2.5 rounded-[18px] border-4 bg-[#FAF6E8] p-3.5"
                style={{ borderColor: active === i ? "#E5533D" : INK, boxShadow: "5px 5px 0 " + (active === i ? "#E5533D" : INK) }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-[7px]">
                    <span className="text-[13px] font-black text-[#E5533D]">{m.slot}</span>
                    {changed && <span className="rounded-full border-2 border-[#12140F] bg-[#F5D547] px-2 py-[2px] text-[11px] font-black">변경됨</span>}
                  </div>
                  <span className="rounded-full border-2 border-[#12140F] bg-[#EDEAD8] px-2.5 py-[3px] text-[11px] font-extrabold">{m.category}</span>
                </div>
                <div className="font-title text-[22px] leading-[1.2]">{m.name}</div>
                <div className="text-[13px] font-bold text-[#4A5140]">{m.branch}</div>
                <div className="flex flex-wrap items-baseline gap-2">
                  <span className="font-title text-[24px] leading-none">{m.mainPrice}</span>
                  <span className="text-[13px] font-bold text-[#4A5140]">내 부담 · {m.dist}</span>
                </div>
                <div className="flex flex-wrap items-center gap-[7px]">
                  <span className={"rounded-full border-2 border-[#12140F] px-2.5 py-[3px] text-[11px] font-extrabold " + (m.tone === "blue" ? "bg-[#D3E7F8]" : "bg-[#CDEBC8]")}>{m.tag}</span>
                  <span className="text-[11px] font-semibold text-[#6B7360]">{m.priceNote}</span>
                </div>
                <p className="text-[13px] font-semibold leading-[1.55] text-[#3C4633]">{m.desc}</p>
                <div className="flex items-center justify-between gap-2.5">
                  <a href="#" className="text-[13px] font-black text-[#1B7F3B] underline">카카오맵에서 보기</a>
                  <button onClick={(e) => { e.stopPropagation(); setFbOpen((p) => ({ ...p, [i]: !p[i] })); }}
                    className="min-h-[44px] rounded-full border-2 border-[#12140F] bg-white px-3.5 text-[13px] font-black">{fbOpen[i] ? "닫기" : "···"}</button>
                </div>
                {fbOpen[i] && (
                  <div className="flex flex-col gap-2.5">
                    <div className="h-0.5 bg-[#DDD9C6]" />
                    <div className="flex flex-wrap gap-[7px]">
                      {["이것만 바꾸기", "너무 멀어요", "비싸요", "안 끌려요"].map((f) => (
                        <button key={f} className="min-h-[44px] rounded-full border-2 border-[#12140F] bg-white px-3 text-[12px] font-extrabold">{f}</button>
                      ))}
                      <button className="min-h-[44px] rounded-full border-2 border-[#E5533D] bg-white px-3 text-[12px] font-extrabold text-[#E5533D]">이곳 제외하기</button>
                    </div>
                  </div>
                )}
              </div>
            ))}

            <div className={"p-[15px] text-[14px] font-black " + panel}>내가 뺀 가게 (0)</div>
          </div>
        )}
      </div>
    </div>
  );
}

/* globals.css 에 추가:
@keyframes bob { 0%,100% { transform: translateY(0) rotate(-1deg) } 50% { transform: translateY(-7px) rotate(1deg) } }
@keyframes shimmer { 0% { background-position: 140% 0 } 100% { background-position: -40% 0 } }
@keyframes steam { 0% { transform: translateY(0) scaleX(1); opacity: 0 } 25% { opacity: .9 } 100% { transform: translateY(-22px) scaleX(1.5); opacity: 0 } }
@keyframes bar { 0% { width: 8% } 60% { width: 72% } 100% { width: 96% } }
.font-title { font-family: var(--font-black-han-sans), sans-serif }
*/

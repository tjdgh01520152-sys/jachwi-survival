# Handoff: 자취생 생존기 홈 + 결과 화면 리디자인

## Overview
Korean hackathon web app "자취생 생존기". 사용자가 위치·예산·끼니 수를 입력하면 근처 식당/편의점/직접요리를 섞은 "생존 루트"를 추천한다. 이 핸드오프는 홈 화면 + 결과 화면(같은 페이지 아래로 펼쳐짐)의 리디자인이다. 기존 Next.js/Tailwind 프로젝트에 이 디자인을 그대로 재현하는 것이 목표.

## About the Design Files
번들에 포함된 HTML은 **디자인 레퍼런스(프로토타입)** 이다. 프로덕션 코드로 복사해 쓰라는 것이 아니라, 기존 Next.js + Tailwind 코드베이스의 패턴(컴포넌트 구조, 상태관리, 카카오맵 SDK 연동 등)으로 **동일한 외형과 동작을 재현**하라는 뜻이다. 문구(한국어 카피)와 정보 구조는 그대로 유지할 것.

## Fidelity
**High-fidelity.** 색상·타이포·간격·보더·그림자 값이 최종값이다. 픽셀 단위로 맞춰 재현할 것.

## Design Tokens
색상
- ink (모든 외곽선/본문): #12140F
- paper (카드 배경): #FAF6E8
- moss (페이지 배경): #B7D48F / 도트 패턴 색 #9BBE72
- coin (강조 노랑): #F5D547
- ramen (CTA/선택 상태 빨강): #E5533D
- cool (보조 파랑): #7FB8E8
- 초록 텍스트/링크: #1B7F3B
- 서브 텍스트: #6B7360, #4A5140, #3C4633
- 얕은 배경: #EDEAD8, 구분선 #DDD9C6
- 뱃지 배경: 초록 #CDEBC8, 파랑 #D3E7F8
- 선택된 플랜 배경: #FFE9E4 (보더 #E5533D)

타이포 (Google Fonts)
- 제목: Black Han Sans — 히어로 48~68px(clamp(46px,15vw,68px)), 카드 제목 22px, 등급 뱃지 20px, CTA 26px
- 본문: Gothic A1 — 400/600/700/800/900. 본문 13~15px, 라벨 11~12px
- 손글씨 액센트: Gamja Flower (현재 미사용, 필요 시)

형태
- 카드: border 4px solid ink, border-radius 20px, box-shadow 6px 6px 0 ink (작은 카드 3px/18px/5px)
- 칩/버튼: border 2~3px solid ink, border-radius 999px
- CTA 버튼: radius 18px, shadow 7px 7px 0 ink, active 시 translate(4px,4px) + shadow 3px 3px 0
- 페이지 배경: radial-gradient(#9BBE72 1.5px, transparent 1.6px) / background-size 18px 18px

간격
- 페이지 패딩 14px 12px 40px, 콘텐츠 최대 폭 460px (모바일 우선, 중앙 정렬)
- 섹션 간 gap 14~16px, 카드 내부 gap 9~14px, 칩 gap 7~8px

## Screens / Views

### 1. 홈 (항상 표시)
레이아웃: 세로 flex, gap 16px.
1. 배지 행: "SURVIVAL MODE" (ink 배경, coin 텍스트, 12px/900, letter-spacing .14em, pill)
2. 히어로 카드 (coin 배경, ink 보더 4px, radius 22px, shadow 8px 8px 0 ink, padding 22px 18px 20px)
   - 제목 "자취생<br>생존기" — Black Han Sans, clamp(46px,15vw,68px), line-height .92, text-shadow 4px 4px 0 #FAF6E8
   - 부제 "아슬아슬한 식비,<br>끝까지 버틸 수 있을까?" — 900, clamp(17px,5vw,21px)
   - 우상단 회전 배지 "EP.1 개강" — ramen 배경, 흰 글자, rotate(7deg), top:-14px right:-8px
3. 마스코트 카드 (paper): 좌측 SVG 마스코트(108×126, bob 애니메이션 3.4s), 우측 말풍선 "라면만 먹고 버티긴<br>좀 그렇잖아요?" (흰 배경, 보더 3px, 좌하단 회전 사각형 꼬리)
4. 설명 문단: "위치, 예산, 끼니 수만 입력하면 근처 식당, 편의점, 직접요리를 섞어 현실적인 생존 루트를 짜드려요." — 600/15px, line-height 1.6
5. MISSION 입력 카드 (paper)
   - 헤더: 빨간 점(9px 원) + "MISSION 입력" (900/12px, letter-spacing .12em)
   - 입력 문장(800/19px, line-height 2.1): 나는 [장소 input] 근처에서 [예산 input]원 으로 [끼니 input]끼 를 버텨야 한다
     - input 스타일: 배경 coin, border 없음, border-bottom 3px solid ink, 가운데 정렬, 900/19px, 폭 각각 5.6em / 4.6em / 2.2em, inputMode="numeric"(숫자칸)
     - 예산은 입력 즉시 천단위 콤마 포맷, 숫자 외 문자는 제거, 최대 9,999,999 / 끼니 최대 99
   - 하단 요약 박스: 점선 보더(2px dashed #9AA18C), 배경 #EDEAD8, radius 12px — 좌 "한 끼 평균 가능 금액"(700/13px), 우 계산값(900/17px) = 예산 ÷ 끼니 수 반올림
6. "더 정확한 추천을 원한다면 (선택 사항)" 카드 (paper) — 그룹별 라벨(800/12px, #6B7360) + 칩 행
   - 거리·가격 성향 (하나만 선택): 가까운 곳 우선 / 균형 / 멀어도 가성비
   - 구성: 요리 섞기 / 편의점 OK / 든든하게
   - 반복 허용도 (하나만 선택): 다양하게 먹기 / 적당히 반복 가능 / 싸면 반복 OK
   - 나눠먹기: 나눠먹기 가능
   - 식사 스타일 (하나만 선택): 최대한 싸게 / 적당히 든든하게 / 세트/사이드도 OK
   - 좋아하는 취향: 매운 음식 / 고기 / 국물 메뉴 / 한식 선호 + "더 보기 +8" (면 요리, 밥 위주, 분식, 양식, 중식, 일식, 샐러드, 디저트)
   - 피하고 싶은 것: 매운 음식 피하기 / 면 피하기 / 고기 피하기 + "더 보기 +5" (해산물, 유제품, 기름진 음식, 밀가루, 내장류 피하기)
   - 칩: 미선택 = 흰 배경 + #C9CDBD 보더 3px + ink 글자 / 선택 = ramen 배경 + ink 보더 + #FFF8EC 글자, padding 8px 14px, 800/13px
   - "더 보기" 칩: 점선 보더 3px dashed #B4B9A8, 투명 배경, #6B7360 글자 — 누르면 해당 그룹의 추가 옵션이 펼쳐지고 칩은 사라짐
   - 하단 안내: "선택하지 않아도 기본값으로 추천이 돌아가요." (700/12px, #6B7360)
7. 메인 CTA "생존 루트 뽑기" — 전체 폭, ramen 배경, #FFF8EC 글자, Black Han Sans 26px, padding 20px 16px, radius 18px, shadow 7px 7px 0 ink, :active 눌림 효과
8. 태그 행(가운데 정렬): 근처 식당 / 편의점 조합 / 직접요리 — paper 배경 pill, 보더 3px, 800/12px

### 2. 결과 (CTA 누르면 홈 아래로 펼쳐짐)
- 별도 페이지/탭 아님. `#dc-result` 컨테이너가 display:none → flex 로 바뀌고, 60ms 뒤 window.scrollTo({ top: el 상단 - 12, behavior:'smooth' }) 로 스크롤.
- 세로 flex, gap 14px.

1) 생존 등급 카드 (paper)
   - 라벨 "생존 등급" (800/12px, #6B7360)
   - 등급 뱃지 "동네 맛집 탐험 계급" — moss 배경, ink 보더 3px, pill, Black Han Sans 20px, padding 9px 16px
   - 우측 문구 "이제 한 끼다운 선택지가 보이기 시작해요." (800/13px)
   - "칭호 · 동네 맛집 탐험가" (700/12px, #6B7360)
   - 지표 타일 3열 그리드(gap 8px, 흰 배경, 보더 3px, radius 12px, 라벨 700/11px + 값 900/15px):
     총 예산 50,000원 / 예상 지출 46,500원 / 예산 사용률 93%(coin 배경 강조) / 남은 돈 3,500원 / 한 끼 평균 11,625원 / 평균 거리 95m
   - 칩 행(#EDEAD8 배경, 보더 2px): 메뉴 다양성 100점 / 외식 4끼 / 편의점 0끼 / 요리 0끼
   - 하단: "추천 성향 · 가격 민감도 높음 · 가까운 곳 선호"

2) 안암 생존 지도 카드 (paper)
   - 헤더 "안암 생존 지도"(900/15px) + 범례(내 위치 ink / 식당 ramen / 편의점 #1B7F3B, 9px 원 + 800/11px)
   - 지도 영역: height 190px, 보더 3px ink, radius 14px, overflow hidden. **여기에 카카오맵 SDK를 마운트**한다(현재는 사선 스트라이프 플레이스홀더 + 좌하단 모노스페이스 라벨).
   - 핀 마커: ramen 배경 + ink 보더 3px + pill, 900/12px, 라벨 "1끼~4끼"; 내 위치 핀만 ink 배경 + #FFF8EC 글자

3) 플랜 선택 행 (flex-wrap, gap 8px)
   - 최대 절약 플랜 / 18,833원 · 평균 249m
   - 균형 플랜 / 46,500원 · 평균 95m  ← 기본 선택
   - 가까운 곳 위주 플랜 / 45,700원 · 평균 146m
   - 카드형 버튼: flex 1 1 130px, radius 14px, padding 11px 13px, 미선택 paper + ink 보더 3px, 선택 #FFE9E4 + #E5533D 보더. 이름 900/14px, 메타 700/12px #4A5140
   - 우측 "전체 다시 추천" 버튼: coin 배경, ink 보더 3px, radius 14px, 900/13px — 누르면 루트 재추첨

4) 끼니 카드 (세로 스택, margin-bottom 12px, paper, 보더 4px, radius 18px, shadow 5px 5px 0 ink)
   - 상단 행: 좌 "1번째 끼니 · 외식" (900/13px, ramen) / 우 카테고리 칩 "본죽&비빔밥cafe" (#EDEAD8, 보더 2px, 800/11px)
   - 메뉴명: Black Han Sans 22px
   - 지점명: 700/13px #4A5140
   - 가격 행: 가격(900/14px) + 태그 뱃지 + "· 거리"
     - 프랜차이즈 기준가 뱃지: #CDEBC8 배경 / 나눠먹기 뱃지: #D3E7F8 배경, 둘 다 ink 보더 2px, pill, 800/11px
   - 설명문: 600/13px, line-height 1.55, #3C4633
   - 링크 "카카오맵에서 보기" — 900/13px, #1B7F3B, 밑줄
   - 구분선 2px #DDD9C6
   - 피드백 칩 행: 이것만 바꾸기 / 너무 멀어요 / 비싸요 / 안 끌려요 (흰 배경, ink 보더 2px) + 이곳 제외하기 (흰 배경, #E5533D 보더/글자)
   - 카드 4장의 내용(현재 더미): 
     1. 1번째 끼니 · 외식 / 본죽&비빔밥cafe / 7가지야채죽 / 본죽&비빔밥cafe 고려대점 / 프랜차이즈 기준가 10,000원 / 48m
     2. 2번째 끼니 · 외식 / 등촌샤브칼국수 / 등촌샤브칼국수 (나눠먹기) / 등촌샤브칼국수 안암점 / 총 20,000원 · 2명 기준 내 부담 10,000원 / 92m
     3. 3번째 끼니 · 외식 / 돈까스,우동 / 이세돈가스 고려대점 / 예상 13,000원대 / 188m
     4. 4번째 끼니 · 외식 / 인도음식 / 오샬 / 예상 13,000원대 / 51m

5) "내 추천에서 숨긴 식당 보기 (0)" — paper 카드, 900/14px

## Interactions & Behavior
- 예산/끼니 수: 문장 안 input 에서 직접 타이핑. 숫자만 허용, 예산은 천단위 콤마 자동. 변경 시 "한 끼 평균 가능 금액" 즉시 재계산.
- 선택 사항 칩: single 그룹은 라디오처럼 1개(다시 누르면 해제), 나머지는 다중 토글. "더 보기 +N" 누르면 추가 옵션 노출.
- CTA "생존 루트 뽑기": 결과 섹션 표시 + 부드러운 스크롤. 결과는 홈 아래에 계속 남아 있음(화면 전환 없음).
- 플랜 버튼: 선택 상태 변경 + 해당 플랜의 끼니 카드 세트로 교체.
- "전체 다시 추천": 루트 재생성.
- 버튼 :active — transform translate(4px,4px), shadow 축소(하드 섀도 눌림 효과).
- 마스코트: bob 3.4s ease-in-out infinite(위아래 7px + 미세 회전), 눈 blink 5s.
- 반응형: 최대 폭 460px 중앙 정렬, 모든 행은 flex-wrap. input font-size 16px 이상 유지(iOS 자동 줌 방지). 터치 타겟 44px 이상 권장.

## State Management
- place: string (기본 '안암역')
- budget: number (기본 50000)
- meals: number (기본 4)
- prefs: { [groupKey]: string[] } — 선택 사항 칩
- prefsOpen: { [groupKey]: boolean } — "더 보기" 펼침
- revealed: boolean — 결과 노출 여부
- plan: number (기본 1 = 균형 플랜)
- seed: number — 루트 재추첨
- 실제 구현: 위치/예산/끼니/선호도를 추천 API 로 보내고 플랜 3종 + 끼니 카드 + 지도 좌표를 받아 렌더. 카카오맵은 지도 컨테이너에 마운트.

## Tailwind 적용 메모
- tailwind.config colors: ink '#12140F', paper '#FAF6E8', moss '#B7D48F', coin '#F5D547', ramen '#E5533D', cool '#7FB8E8'
- 공용 클래스: `.panel { @apply bg-paper border-4 border-ink rounded-2xl shadow-[6px_6px_0_#12140F]; }`
- 버튼 눌림: `active:translate-x-1 active:translate-y-1 active:shadow-[3px_3px_0_#12140F]`
- 배경: `bg-[radial-gradient(#9BBE72_1.5px,transparent_1.6px)] bg-[length:18px_18px]`
- 폰트: next/font/google 의 Black_Han_Sans(제목), Gothic_A1(본문)

## Assets
- 이미지 에셋 없음. 마스코트는 인라인 SVG(원/패스 조합, stroke #12140F 5px)로 그린 **임시 스케치**다. 최종본은 일러스트레이터가 그린 PNG/SVG로 교체 권장 — 방향: 후드 입은 자취생, 큰 머리·작은 몸, 처진 눈썹과 물결 입(어색하지만 귀여움), 컵라면을 든 포즈, 두꺼운 검정 외곽선 + 플랫 컬러. 결과 등급별로 표정만 교체.
- 지도는 카카오맵 SDK 사용(현재 플레이스홀더).

## Files
- `자취생 생존기 Homepage.dc.html` — 홈 + 결과 전체 디자인 (브라우저에서 바로 열림). 스타일은 전부 인라인이므로 값 참조가 쉽다.


## 업데이트 (최신 반영 사항)
- 화면 전환 없음: "생존 루트 뽑기" → **로딩(약 2초)** → 결과가 같은 페이지 아래로 펼쳐짐. 실제 구현에선 타이머를 추천 API 응답으로 교체.
- **로딩 스켈레톤**: 라면 냄비 앞 마스코트(bob) + 김 3줄(steam) + 진행 바(bar) + 0.7초마다 바뀌는 문구 4종, 그 아래 결과 레이아웃을 그대로 본뜬 시머 스켈레톤(등급 카드 / 지도 / 끼니 카드 2장). 스켈레톤도 동일한 4px 검정 외곽선 + 하드 섀도 유지.
- **입력 카드 접힘**: 결과가 나오면 입력 카드가 "안암역 · 50,000원 · 4끼 + [수정]" 한 줄 요약으로 접힘.
- **선택 사항 카드 기본 접힘**: 헤더 우측 "더 정확하게 + / 접기 −" 토글.
- **등급 카드 위계 정리**: 예산 사용률(coin 배경)·남은 돈(ink 배경) 2개만 30px 대형 수치, 나머지 4개는 라벨-값 목록으로 축소. 좌측에 등급 마스코트 얼굴 추가(등급별 표정 교체 전제).
- **가격 표기 통일**: 실제 내 부담 금액을 24px Black Han Sans 로 항상 먼저, 조건(프랜차이즈 기준가/2명 기준 등)은 11px 보조 텍스트로 강등.
- **피드백 칩 접힘**: 카드마다 "···" 버튼으로 열고 닫음. 모든 칩 min-height 44px.
- **지도-카드 연동**: 끼니 카드를 누르면 해당 카드 보더가 ramen 으로 바뀌고 지도 핀이 ink + scale(1.25) 로 강조.
- **플랜 변경 피드백**: 플랜 전환/전체 다시 추천 시 카드에 "변경됨" 뱃지가 1.8초 표시.
- **터치 타겟**: 문장 입력칸 패딩 9px 8px, 모든 버튼 min-height 44px.
- 문구 변경: 히어로 부제 "아슬아슬한 식비, 끝까지 버틸 수 있을까?", 하단 "내가 뺀 가게 (0)". "이번 달 잔액 D-12"와 "지금까지 2,418명…" 문구 삭제.

## 바로 쓸 수 있는 파일
- `SurvivalHome.tsx` — 위 내용이 모두 반영된 React(Next.js App Router, "use client") + Tailwind 컴포넌트. app/page.tsx 에서 import 후 렌더하면 됨. 파일 하단 주석의 keyframes 4개와 .font-title 정의를 globals.css 에 추가할 것.
- Tailwind arbitrary 값(`bg-[#B7D48F]` 등)을 쓰므로 tailwind.config 의 content 경로에 이 파일이 포함돼야 함(안 그러면 색·보더가 전부 빠져 보임).
